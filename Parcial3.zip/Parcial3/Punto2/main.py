import sys
from antlr4 import *
from GramaticaLexer import GramaticaLexer
from GramaticaParser import GramaticaParser
from VisitorGramatica import InterpreteGramatica

def main():
    if len(sys.argv) != 2:
        print("Uso: python3 main.py archivo.txt")
        sys.exit(1)
    
    filename = sys.argv[1]
    
    try:
        # Leer el archivo de entrada
        with open(filename, 'r') as file:
            codigo = file.read()
        
        print("=== Ejecutando código ===")
        print(codigo)
        print("=== Resultados ===")
        
        # Crear el lexer y parser
        input_stream = InputStream(codigo)
        lexer = GramaticaLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = GramaticaParser(stream)
        
        # Parsear el programa
        arbol = parser.programa()
        
        # Verificar si hay errores de sintaxis
        if parser.getNumberOfSyntaxErrors() > 0:
            print("Errores de sintaxis encontrados:")
            return
        
        # Ejecutar el interprete
        interprete = InterpreteGramatica()
        resultados = interprete.visit(arbol)
        
        print("\nEjecución completada exitosamente")
        
    except FileNotFoundError:
        print(f"Error: No se pudo encontrar el archivo '{filename}'")
    except Exception as e:
        print(f"Error durante la ejecución: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()
