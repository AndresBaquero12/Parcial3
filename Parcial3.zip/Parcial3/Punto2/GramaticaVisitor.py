# Generated from Gramatica.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .GramaticaParser import GramaticaParser
else:
    from GramaticaParser import GramaticaParser

# This class defines a complete generic visitor for a parse tree produced by GramaticaParser.

class GramaticaVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by GramaticaParser#programa.
    def visitPrograma(self, ctx:GramaticaParser.ProgramaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by GramaticaParser#instruccion.
    def visitInstruccion(self, ctx:GramaticaParser.InstruccionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by GramaticaParser#declaracionMatriz.
    def visitDeclaracionMatriz(self, ctx:GramaticaParser.DeclaracionMatrizContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by GramaticaParser#asignacion.
    def visitAsignacion(self, ctx:GramaticaParser.AsignacionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by GramaticaParser#instruccionImprimir.
    def visitInstruccionImprimir(self, ctx:GramaticaParser.InstruccionImprimirContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by GramaticaParser#ExpresionNumero.
    def visitExpresionNumero(self, ctx:GramaticaParser.ExpresionNumeroContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by GramaticaParser#Parentesis.
    def visitParentesis(self, ctx:GramaticaParser.ParentesisContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by GramaticaParser#ExpresionID.
    def visitExpresionID(self, ctx:GramaticaParser.ExpresionIDContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by GramaticaParser#ProductoPunto.
    def visitProductoPunto(self, ctx:GramaticaParser.ProductoPuntoContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by GramaticaParser#MultiplicacionDivision.
    def visitMultiplicacionDivision(self, ctx:GramaticaParser.MultiplicacionDivisionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by GramaticaParser#ExpresionMatriz.
    def visitExpresionMatriz(self, ctx:GramaticaParser.ExpresionMatrizContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by GramaticaParser#SumaResta.
    def visitSumaResta(self, ctx:GramaticaParser.SumaRestaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by GramaticaParser#literalMatriz.
    def visitLiteralMatriz(self, ctx:GramaticaParser.LiteralMatrizContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by GramaticaParser#fila.
    def visitFila(self, ctx:GramaticaParser.FilaContext):
        return self.visitChildren(ctx)



del GramaticaParser