import numpy as np
from MatrixGrammarVisitor import MatrixGrammarVisitor
from MatrixGrammarParser import MatrixGrammarParser

class MatrixInterpreter(MatrixGrammarVisitor):
    def __init__(self):
        self.variables = {}
    
    def visitProgram(self, ctx: MatrixGrammarParser.ProgramContext):
        results = []
        for stmt in ctx.statement():
            try:
                result = self.visit(stmt)
                if result is not None:
                    results.append(result)
            except Exception as e:
                print(f"Error en línea: {e}")
                raise
        return results
    
    def visitMatrixDeclaration(self, ctx: MatrixGrammarParser.MatrixDeclarationContext):
        matrix_id = ctx.ID().getText()
        matrix_value = self.visit(ctx.matrixLiteral())
        self.variables[matrix_id] = matrix_value
        return matrix_value
    
    def visitAssignment(self, ctx: MatrixGrammarParser.AssignmentContext):
        var_name = ctx.ID().getText()
        value = self.visit(ctx.expression())
        self.variables[var_name] = value
        return value
    
    def visitPrintStatement(self, ctx: MatrixGrammarParser.PrintStatementContext):
        value = self.visit(ctx.expression())
        print(">>>", value)
        return value
    
    def visitDotProduct(self, ctx: MatrixGrammarParser.DotProductContext):
        left = self.visit(ctx.expression(0))
        right = self.visit(ctx.expression(1))
        
        left_arr = np.array(left)
        right_arr = np.array(right)
        
        print(f"Calculando producto punto entre: {left_arr.shape} y {right_arr.shape}")
        
        try:
            result = np.dot(left_arr, right_arr)
            if result.ndim == 0:
                return float(result)
            else:
                return result.tolist()       
        except ValueError as e:
            raise ValueError(f"Error en producto punto: {e}")
    
    def visitAddSub(self, ctx: MatrixGrammarParser.AddSubContext):
        left = self.visit(ctx.expression(0))
        right = self.visit(ctx.expression(1))
        op = ctx.op.text
        
        left_arr = np.array(left)
        right_arr = np.array(right)
        
        if op == '+':
            result = left_arr + right_arr
        else:
            result = left_arr - right_arr
        
        if result.ndim == 0:
            return float(result)
        else:
            return result.tolist()
    
    def visitMulDiv(self, ctx: MatrixGrammarParser.MulDivContext):
        left = self.visit(ctx.expression(0))
        right = self.visit(ctx.expression(1))
        op = ctx.op.text
        
        left_arr = np.array(left)
        right_arr = np.array(right)
        
        if op == '*':
            result = left_arr * right_arr
        else:
            if np.any(right_arr == 0):
                raise ValueError("División por cero")
            result = left_arr / right_arr
        
        if result.ndim == 0:
            return float(result)
        else:
            return result.tolist()
    
    def visitParens(self, ctx: MatrixGrammarParser.ParensContext):
        return self.visit(ctx.expression())
    
    def visitMatrix(self, ctx: MatrixGrammarParser.MatrixContext):
        return self.visit(ctx.matrixLiteral())
    
    def visitVariable(self, ctx: MatrixGrammarParser.VariableContext):
        var_name = ctx.ID().getText()
        if var_name not in self.variables:
            raise NameError(f"Variable no definida: {var_name}")
        return self.variables[var_name]
    
    def visitNumber(self, ctx: MatrixGrammarParser.NumberContext):
        return float(ctx.NUMBER().getText())
    
    def visitMatrixLiteral(self, ctx: MatrixGrammarParser.MatrixLiteralContext):
        matrix = []
        for row_ctx in ctx.row():
            row = []
            for num_ctx in row_ctx.NUMBER():
                row.append(float(num_ctx.getText()))
            matrix.append(row)
        if len(matrix) == 1:
            return matrix[0]
        else:
            return matrix

