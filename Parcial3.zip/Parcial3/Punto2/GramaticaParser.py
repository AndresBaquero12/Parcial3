# Generated from Gramatica.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,18,91,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,1,0,1,0,3,0,19,8,0,5,0,21,8,0,10,0,12,0,24,9,0,1,0,1,0,
        1,1,1,1,1,1,3,1,31,8,1,1,2,1,2,1,2,1,2,1,2,1,3,1,3,1,3,1,3,1,4,1,
        4,1,4,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,3,5,53,8,5,1,5,1,5,1,5,1,5,
        1,5,1,5,1,5,1,5,1,5,5,5,64,8,5,10,5,12,5,67,9,5,1,6,1,6,1,6,1,6,
        5,6,73,8,6,10,6,12,6,76,9,6,1,6,1,6,1,7,1,7,1,7,1,7,5,7,84,8,7,10,
        7,12,7,87,9,7,1,7,1,7,1,7,0,1,10,8,0,2,4,6,8,10,12,14,0,2,1,0,6,
        7,1,0,8,9,94,0,22,1,0,0,0,2,30,1,0,0,0,4,32,1,0,0,0,6,37,1,0,0,0,
        8,41,1,0,0,0,10,52,1,0,0,0,12,68,1,0,0,0,14,79,1,0,0,0,16,18,3,2,
        1,0,17,19,5,1,0,0,18,17,1,0,0,0,18,19,1,0,0,0,19,21,1,0,0,0,20,16,
        1,0,0,0,21,24,1,0,0,0,22,20,1,0,0,0,22,23,1,0,0,0,23,25,1,0,0,0,
        24,22,1,0,0,0,25,26,5,0,0,1,26,1,1,0,0,0,27,31,3,4,2,0,28,31,3,6,
        3,0,29,31,3,8,4,0,30,27,1,0,0,0,30,28,1,0,0,0,30,29,1,0,0,0,31,3,
        1,0,0,0,32,33,5,2,0,0,33,34,5,15,0,0,34,35,5,3,0,0,35,36,3,12,6,
        0,36,5,1,0,0,0,37,38,5,15,0,0,38,39,5,3,0,0,39,40,3,10,5,0,40,7,
        1,0,0,0,41,42,5,4,0,0,42,43,3,10,5,0,43,9,1,0,0,0,44,45,6,5,-1,0,
        45,46,5,10,0,0,46,47,3,10,5,0,47,48,5,11,0,0,48,53,1,0,0,0,49,53,
        3,12,6,0,50,53,5,15,0,0,51,53,5,16,0,0,52,44,1,0,0,0,52,49,1,0,0,
        0,52,50,1,0,0,0,52,51,1,0,0,0,53,65,1,0,0,0,54,55,10,7,0,0,55,56,
        5,5,0,0,56,64,3,10,5,8,57,58,10,6,0,0,58,59,7,0,0,0,59,64,3,10,5,
        7,60,61,10,5,0,0,61,62,7,1,0,0,62,64,3,10,5,6,63,54,1,0,0,0,63,57,
        1,0,0,0,63,60,1,0,0,0,64,67,1,0,0,0,65,63,1,0,0,0,65,66,1,0,0,0,
        66,11,1,0,0,0,67,65,1,0,0,0,68,69,5,12,0,0,69,74,3,14,7,0,70,71,
        5,13,0,0,71,73,3,14,7,0,72,70,1,0,0,0,73,76,1,0,0,0,74,72,1,0,0,
        0,74,75,1,0,0,0,75,77,1,0,0,0,76,74,1,0,0,0,77,78,5,14,0,0,78,13,
        1,0,0,0,79,80,5,12,0,0,80,85,5,16,0,0,81,82,5,13,0,0,82,84,5,16,
        0,0,83,81,1,0,0,0,84,87,1,0,0,0,85,83,1,0,0,0,85,86,1,0,0,0,86,88,
        1,0,0,0,87,85,1,0,0,0,88,89,5,14,0,0,89,15,1,0,0,0,8,18,22,30,52,
        63,65,74,85
    ]

class GramaticaParser ( Parser ):

    grammarFileName = "Gramatica.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "';'", "'matrix'", "'='", "'print'", "'.'", 
                     "'*'", "'/'", "'+'", "'-'", "'('", "')'", "'['", "','", 
                     "']'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "ID", "NUMERO", 
                      "WS", "COMENTARIO" ]

    RULE_programa = 0
    RULE_instruccion = 1
    RULE_declaracionMatriz = 2
    RULE_asignacion = 3
    RULE_instruccionImprimir = 4
    RULE_expresion = 5
    RULE_literalMatriz = 6
    RULE_fila = 7

    ruleNames =  [ "programa", "instruccion", "declaracionMatriz", "asignacion", 
                   "instruccionImprimir", "expresion", "literalMatriz", 
                   "fila" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    ID=15
    NUMERO=16
    WS=17
    COMENTARIO=18

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(GramaticaParser.EOF, 0)

        def instruccion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.InstruccionContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.InstruccionContext,i)


        def getRuleIndex(self):
            return GramaticaParser.RULE_programa

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrograma" ):
                listener.enterPrograma(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrograma" ):
                listener.exitPrograma(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrograma" ):
                return visitor.visitPrograma(self)
            else:
                return visitor.visitChildren(self)




    def programa(self):

        localctx = GramaticaParser.ProgramaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_programa)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 22
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 32788) != 0):
                self.state = 16
                self.instruccion()
                self.state = 18
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==1:
                    self.state = 17
                    self.match(GramaticaParser.T__0)


                self.state = 24
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 25
            self.match(GramaticaParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstruccionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def declaracionMatriz(self):
            return self.getTypedRuleContext(GramaticaParser.DeclaracionMatrizContext,0)


        def asignacion(self):
            return self.getTypedRuleContext(GramaticaParser.AsignacionContext,0)


        def instruccionImprimir(self):
            return self.getTypedRuleContext(GramaticaParser.InstruccionImprimirContext,0)


        def getRuleIndex(self):
            return GramaticaParser.RULE_instruccion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstruccion" ):
                listener.enterInstruccion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstruccion" ):
                listener.exitInstruccion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstruccion" ):
                return visitor.visitInstruccion(self)
            else:
                return visitor.visitChildren(self)




    def instruccion(self):

        localctx = GramaticaParser.InstruccionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_instruccion)
        try:
            self.state = 30
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [2]:
                self.enterOuterAlt(localctx, 1)
                self.state = 27
                self.declaracionMatriz()
                pass
            elif token in [15]:
                self.enterOuterAlt(localctx, 2)
                self.state = 28
                self.asignacion()
                pass
            elif token in [4]:
                self.enterOuterAlt(localctx, 3)
                self.state = 29
                self.instruccionImprimir()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclaracionMatrizContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(GramaticaParser.ID, 0)

        def literalMatriz(self):
            return self.getTypedRuleContext(GramaticaParser.LiteralMatrizContext,0)


        def getRuleIndex(self):
            return GramaticaParser.RULE_declaracionMatriz

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclaracionMatriz" ):
                listener.enterDeclaracionMatriz(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclaracionMatriz" ):
                listener.exitDeclaracionMatriz(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeclaracionMatriz" ):
                return visitor.visitDeclaracionMatriz(self)
            else:
                return visitor.visitChildren(self)




    def declaracionMatriz(self):

        localctx = GramaticaParser.DeclaracionMatrizContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_declaracionMatriz)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 32
            self.match(GramaticaParser.T__1)
            self.state = 33
            self.match(GramaticaParser.ID)
            self.state = 34
            self.match(GramaticaParser.T__2)
            self.state = 35
            self.literalMatriz()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AsignacionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(GramaticaParser.ID, 0)

        def expresion(self):
            return self.getTypedRuleContext(GramaticaParser.ExpresionContext,0)


        def getRuleIndex(self):
            return GramaticaParser.RULE_asignacion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAsignacion" ):
                listener.enterAsignacion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAsignacion" ):
                listener.exitAsignacion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAsignacion" ):
                return visitor.visitAsignacion(self)
            else:
                return visitor.visitChildren(self)




    def asignacion(self):

        localctx = GramaticaParser.AsignacionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_asignacion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 37
            self.match(GramaticaParser.ID)
            self.state = 38
            self.match(GramaticaParser.T__2)
            self.state = 39
            self.expresion(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstruccionImprimirContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expresion(self):
            return self.getTypedRuleContext(GramaticaParser.ExpresionContext,0)


        def getRuleIndex(self):
            return GramaticaParser.RULE_instruccionImprimir

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstruccionImprimir" ):
                listener.enterInstruccionImprimir(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstruccionImprimir" ):
                listener.exitInstruccionImprimir(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstruccionImprimir" ):
                return visitor.visitInstruccionImprimir(self)
            else:
                return visitor.visitChildren(self)




    def instruccionImprimir(self):

        localctx = GramaticaParser.InstruccionImprimirContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_instruccionImprimir)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 41
            self.match(GramaticaParser.T__3)
            self.state = 42
            self.expresion(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpresionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return GramaticaParser.RULE_expresion

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class ExpresionNumeroContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a GramaticaParser.ExpresionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NUMERO(self):
            return self.getToken(GramaticaParser.NUMERO, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpresionNumero" ):
                listener.enterExpresionNumero(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpresionNumero" ):
                listener.exitExpresionNumero(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpresionNumero" ):
                return visitor.visitExpresionNumero(self)
            else:
                return visitor.visitChildren(self)


    class ParentesisContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a GramaticaParser.ExpresionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expresion(self):
            return self.getTypedRuleContext(GramaticaParser.ExpresionContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParentesis" ):
                listener.enterParentesis(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParentesis" ):
                listener.exitParentesis(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParentesis" ):
                return visitor.visitParentesis(self)
            else:
                return visitor.visitChildren(self)


    class ExpresionIDContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a GramaticaParser.ExpresionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(GramaticaParser.ID, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpresionID" ):
                listener.enterExpresionID(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpresionID" ):
                listener.exitExpresionID(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpresionID" ):
                return visitor.visitExpresionID(self)
            else:
                return visitor.visitChildren(self)


    class ProductoPuntoContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a GramaticaParser.ExpresionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expresion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.ExpresionContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.ExpresionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProductoPunto" ):
                listener.enterProductoPunto(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProductoPunto" ):
                listener.exitProductoPunto(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProductoPunto" ):
                return visitor.visitProductoPunto(self)
            else:
                return visitor.visitChildren(self)


    class MultiplicacionDivisionContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a GramaticaParser.ExpresionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expresion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.ExpresionContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.ExpresionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMultiplicacionDivision" ):
                listener.enterMultiplicacionDivision(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMultiplicacionDivision" ):
                listener.exitMultiplicacionDivision(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMultiplicacionDivision" ):
                return visitor.visitMultiplicacionDivision(self)
            else:
                return visitor.visitChildren(self)


    class ExpresionMatrizContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a GramaticaParser.ExpresionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def literalMatriz(self):
            return self.getTypedRuleContext(GramaticaParser.LiteralMatrizContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpresionMatriz" ):
                listener.enterExpresionMatriz(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpresionMatriz" ):
                listener.exitExpresionMatriz(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpresionMatriz" ):
                return visitor.visitExpresionMatriz(self)
            else:
                return visitor.visitChildren(self)


    class SumaRestaContext(ExpresionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a GramaticaParser.ExpresionContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expresion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.ExpresionContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.ExpresionContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSumaResta" ):
                listener.enterSumaResta(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSumaResta" ):
                listener.exitSumaResta(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSumaResta" ):
                return visitor.visitSumaResta(self)
            else:
                return visitor.visitChildren(self)



    def expresion(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = GramaticaParser.ExpresionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 10
        self.enterRecursionRule(localctx, 10, self.RULE_expresion, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 52
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [10]:
                localctx = GramaticaParser.ParentesisContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 45
                self.match(GramaticaParser.T__9)
                self.state = 46
                self.expresion(0)
                self.state = 47
                self.match(GramaticaParser.T__10)
                pass
            elif token in [12]:
                localctx = GramaticaParser.ExpresionMatrizContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 49
                self.literalMatriz()
                pass
            elif token in [15]:
                localctx = GramaticaParser.ExpresionIDContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 50
                self.match(GramaticaParser.ID)
                pass
            elif token in [16]:
                localctx = GramaticaParser.ExpresionNumeroContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 51
                self.match(GramaticaParser.NUMERO)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 65
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,5,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 63
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
                    if la_ == 1:
                        localctx = GramaticaParser.ProductoPuntoContext(self, GramaticaParser.ExpresionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expresion)
                        self.state = 54
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 55
                        self.match(GramaticaParser.T__4)
                        self.state = 56
                        self.expresion(8)
                        pass

                    elif la_ == 2:
                        localctx = GramaticaParser.MultiplicacionDivisionContext(self, GramaticaParser.ExpresionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expresion)
                        self.state = 57
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 58
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==6 or _la==7):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 59
                        self.expresion(7)
                        pass

                    elif la_ == 3:
                        localctx = GramaticaParser.SumaRestaContext(self, GramaticaParser.ExpresionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expresion)
                        self.state = 60
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 61
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==8 or _la==9):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 62
                        self.expresion(6)
                        pass

             
                self.state = 67
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class LiteralMatrizContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fila(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.FilaContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.FilaContext,i)


        def getRuleIndex(self):
            return GramaticaParser.RULE_literalMatriz

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLiteralMatriz" ):
                listener.enterLiteralMatriz(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLiteralMatriz" ):
                listener.exitLiteralMatriz(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLiteralMatriz" ):
                return visitor.visitLiteralMatriz(self)
            else:
                return visitor.visitChildren(self)




    def literalMatriz(self):

        localctx = GramaticaParser.LiteralMatrizContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_literalMatriz)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 68
            self.match(GramaticaParser.T__11)
            self.state = 69
            self.fila()
            self.state = 74
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==13:
                self.state = 70
                self.match(GramaticaParser.T__12)
                self.state = 71
                self.fila()
                self.state = 76
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 77
            self.match(GramaticaParser.T__13)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FilaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMERO(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.NUMERO)
            else:
                return self.getToken(GramaticaParser.NUMERO, i)

        def getRuleIndex(self):
            return GramaticaParser.RULE_fila

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFila" ):
                listener.enterFila(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFila" ):
                listener.exitFila(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFila" ):
                return visitor.visitFila(self)
            else:
                return visitor.visitChildren(self)




    def fila(self):

        localctx = GramaticaParser.FilaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_fila)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 79
            self.match(GramaticaParser.T__11)
            self.state = 80
            self.match(GramaticaParser.NUMERO)
            self.state = 85
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==13:
                self.state = 81
                self.match(GramaticaParser.T__12)
                self.state = 82
                self.match(GramaticaParser.NUMERO)
                self.state = 87
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 88
            self.match(GramaticaParser.T__13)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[5] = self.expresion_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expresion_sempred(self, localctx:ExpresionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 5)
         




