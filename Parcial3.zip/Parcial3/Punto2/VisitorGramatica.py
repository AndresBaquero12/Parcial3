import numpy as np
from GramaticaVisitor import GramaticaVisitor
from GramaticaParser import GramaticaParser

class InterpreteGramatica(GramaticaVisitor):
    def __init__(self):
        self.variables = {}
    
    def visitPrograma(self, ctx: GramaticaParser.ProgramaContext):
        resultados = []
        for instruccion in ctx.instruccion():
            try:
                resultado = self.visit(instruccion)
                if resultado is not None:
                    resultados.append(resultado)
            except Exception as e:
                print(f"Error en línea: {e}")
                raise
        return resultados
    
    def visitDeclaracionMatriz(self, ctx: GramaticaParser.DeclaracionMatrizContext):
        id_matriz = ctx.ID().getText()
        valor_matriz = self.visit(ctx.literalMatriz())
        self.variables[id_matriz] = valor_matriz
        return valor_matriz
    
    def visitAsignacion(self, ctx: GramaticaParser.AsignacionContext):
        nombre_var = ctx.ID().getText()
        valor = self.visit(ctx.expresion())
        self.variables[nombre_var] = valor
        return valor
    
    def visitInstruccionImprimir(self, ctx: GramaticaParser.InstruccionImprimirContext):
        valor = self.visit(ctx.expresion())
        print(">>>", valor)
        return valor
    
    def visitProductoPunto(self, ctx: GramaticaParser.ProductoPuntoContext):
        izquierda = self.visit(ctx.expresion(0))
        derecha = self.visit(ctx.expresion(1))
        
        # Convertir a arrays numpy
        arr_izquierda = np.array(izquierda)
        arr_derecha = np.array(derecha)
        
        print(f"Calculando producto punto entre: {arr_izquierda.shape} y {arr_derecha.shape}")
        
        # Realizar producto punto/multiplicación de matrices
        try:
            resultado = np.dot(arr_izquierda, arr_derecha)
            
            # Convertir a tipo Python básico si es escalar
            if resultado.ndim == 0:
                return float(resultado)
            else:
                return resultado.tolist()
                
        except ValueError as e:
            raise ValueError(f"Error en producto punto: {e}")
    
    def visitSumaResta(self, ctx: GramaticaParser.SumaRestaContext):
        izquierda = self.visit(ctx.expresion(0))
        derecha = self.visit(ctx.expresion(1))
        operador = ctx.op.text
        
        arr_izquierda = np.array(izquierda)
        arr_derecha = np.array(derecha)
        
        if operador == '+':
            resultado = arr_izquierda + arr_derecha
        else:  # '-'
            resultado = arr_izquierda - arr_derecha
        
        # Convertir de vuelta a lista
        if resultado.ndim == 0:
            return float(resultado)
        else:
            return resultado.tolist()
    
    def visitMultiplicacionDivision(self, ctx: GramaticaParser.MultiplicacionDivisionContext):
        izquierda = self.visit(ctx.expresion(0))
        derecha = self.visit(ctx.expresion(1))
        operador = ctx.op.text
        
        arr_izquierda = np.array(izquierda)
        arr_derecha = np.array(derecha)
        
        if operador == '*':
            resultado = arr_izquierda * arr_derecha
        else:  # '/'
            if np.any(arr_derecha == 0):
                raise ValueError("División por cero")
            resultado = arr_izquierda / arr_derecha
        
        if resultado.ndim == 0:
            return float(resultado)
        else:
            return resultado.tolist()
    
    def visitParentesis(self, ctx: GramaticaParser.ParentesisContext):
        return self.visit(ctx.expresion())
    
    def visitExpresionMatriz(self, ctx: GramaticaParser.ExpresionMatrizContext):
        return self.visit(ctx.literalMatriz())
    
    def visitExpresionID(self, ctx: GramaticaParser.ExpresionIDContext):
        nombre_var = ctx.ID().getText()
        if nombre_var not in self.variables:
            raise NameError(f"Variable no definida: {nombre_var}")
        return self.variables[nombre_var]
    
    def visitExpresionNumero(self, ctx: GramaticaParser.ExpresionNumeroContext):
        return float(ctx.NUMERO().getText())
    
    def visitLiteralMatriz(self, ctx: GramaticaParser.LiteralMatrizContext):
        matriz = []
        for fila_ctx in ctx.fila():
            fila = []
            for num_ctx in fila_ctx.NUMERO():
                fila.append(float(num_ctx.getText()))
            matriz.append(fila)
        
        # Si es un vector (matriz 1xN), simplificar
        if len(matriz) == 1:  # Vector fila
            return matriz[0]
        else:
            return matriz
