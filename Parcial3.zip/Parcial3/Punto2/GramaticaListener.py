# Generated from Gramatica.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .GramaticaParser import GramaticaParser
else:
    from GramaticaParser import GramaticaParser

# This class defines a complete listener for a parse tree produced by GramaticaParser.
class GramaticaListener(ParseTreeListener):

    # Enter a parse tree produced by GramaticaParser#programa.
    def enterPrograma(self, ctx:GramaticaParser.ProgramaContext):
        pass

    # Exit a parse tree produced by GramaticaParser#programa.
    def exitPrograma(self, ctx:GramaticaParser.ProgramaContext):
        pass


    # Enter a parse tree produced by GramaticaParser#instruccion.
    def enterInstruccion(self, ctx:GramaticaParser.InstruccionContext):
        pass

    # Exit a parse tree produced by GramaticaParser#instruccion.
    def exitInstruccion(self, ctx:GramaticaParser.InstruccionContext):
        pass


    # Enter a parse tree produced by GramaticaParser#declaracionMatriz.
    def enterDeclaracionMatriz(self, ctx:GramaticaParser.DeclaracionMatrizContext):
        pass

    # Exit a parse tree produced by GramaticaParser#declaracionMatriz.
    def exitDeclaracionMatriz(self, ctx:GramaticaParser.DeclaracionMatrizContext):
        pass


    # Enter a parse tree produced by GramaticaParser#asignacion.
    def enterAsignacion(self, ctx:GramaticaParser.AsignacionContext):
        pass

    # Exit a parse tree produced by GramaticaParser#asignacion.
    def exitAsignacion(self, ctx:GramaticaParser.AsignacionContext):
        pass


    # Enter a parse tree produced by GramaticaParser#instruccionImprimir.
    def enterInstruccionImprimir(self, ctx:GramaticaParser.InstruccionImprimirContext):
        pass

    # Exit a parse tree produced by GramaticaParser#instruccionImprimir.
    def exitInstruccionImprimir(self, ctx:GramaticaParser.InstruccionImprimirContext):
        pass


    # Enter a parse tree produced by GramaticaParser#ExpresionNumero.
    def enterExpresionNumero(self, ctx:GramaticaParser.ExpresionNumeroContext):
        pass

    # Exit a parse tree produced by GramaticaParser#ExpresionNumero.
    def exitExpresionNumero(self, ctx:GramaticaParser.ExpresionNumeroContext):
        pass


    # Enter a parse tree produced by GramaticaParser#Parentesis.
    def enterParentesis(self, ctx:GramaticaParser.ParentesisContext):
        pass

    # Exit a parse tree produced by GramaticaParser#Parentesis.
    def exitParentesis(self, ctx:GramaticaParser.ParentesisContext):
        pass


    # Enter a parse tree produced by GramaticaParser#ExpresionID.
    def enterExpresionID(self, ctx:GramaticaParser.ExpresionIDContext):
        pass

    # Exit a parse tree produced by GramaticaParser#ExpresionID.
    def exitExpresionID(self, ctx:GramaticaParser.ExpresionIDContext):
        pass


    # Enter a parse tree produced by GramaticaParser#ProductoPunto.
    def enterProductoPunto(self, ctx:GramaticaParser.ProductoPuntoContext):
        pass

    # Exit a parse tree produced by GramaticaParser#ProductoPunto.
    def exitProductoPunto(self, ctx:GramaticaParser.ProductoPuntoContext):
        pass


    # Enter a parse tree produced by GramaticaParser#MultiplicacionDivision.
    def enterMultiplicacionDivision(self, ctx:GramaticaParser.MultiplicacionDivisionContext):
        pass

    # Exit a parse tree produced by GramaticaParser#MultiplicacionDivision.
    def exitMultiplicacionDivision(self, ctx:GramaticaParser.MultiplicacionDivisionContext):
        pass


    # Enter a parse tree produced by GramaticaParser#ExpresionMatriz.
    def enterExpresionMatriz(self, ctx:GramaticaParser.ExpresionMatrizContext):
        pass

    # Exit a parse tree produced by GramaticaParser#ExpresionMatriz.
    def exitExpresionMatriz(self, ctx:GramaticaParser.ExpresionMatrizContext):
        pass


    # Enter a parse tree produced by GramaticaParser#SumaResta.
    def enterSumaResta(self, ctx:GramaticaParser.SumaRestaContext):
        pass

    # Exit a parse tree produced by GramaticaParser#SumaResta.
    def exitSumaResta(self, ctx:GramaticaParser.SumaRestaContext):
        pass


    # Enter a parse tree produced by GramaticaParser#literalMatriz.
    def enterLiteralMatriz(self, ctx:GramaticaParser.LiteralMatrizContext):
        pass

    # Exit a parse tree produced by GramaticaParser#literalMatriz.
    def exitLiteralMatriz(self, ctx:GramaticaParser.LiteralMatrizContext):
        pass


    # Enter a parse tree produced by GramaticaParser#fila.
    def enterFila(self, ctx:GramaticaParser.FilaContext):
        pass

    # Exit a parse tree produced by GramaticaParser#fila.
    def exitFila(self, ctx:GramaticaParser.FilaContext):
        pass



del GramaticaParser