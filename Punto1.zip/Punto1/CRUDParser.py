# Generated from CRUD.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,32,194,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,1,0,4,0,50,8,0,11,0,12,0,51,1,
        0,1,0,1,1,1,1,1,1,1,1,1,1,3,1,61,8,1,1,2,1,2,1,2,1,2,1,2,1,2,1,3,
        1,3,1,3,5,3,72,8,3,10,3,12,3,75,9,3,1,4,1,4,1,4,3,4,80,8,4,1,5,1,
        5,1,5,1,5,1,5,3,5,87,8,5,1,6,1,6,1,6,1,6,4,6,93,8,6,11,6,12,6,94,
        1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,8,1,8,1,8,5,8,108,8,8,10,8,12,
        8,111,9,8,1,9,1,9,1,9,1,9,1,9,3,9,118,8,9,1,10,1,10,1,10,5,10,123,
        8,10,10,10,12,10,126,9,10,1,11,1,11,1,11,1,11,1,11,1,11,3,11,134,
        8,11,1,12,1,12,1,13,1,13,1,13,1,13,1,13,1,13,3,13,144,8,13,1,14,
        1,14,1,14,1,14,1,14,3,14,151,8,14,1,15,1,15,1,15,5,15,156,8,15,10,
        15,12,15,159,9,15,1,16,1,16,1,17,1,17,1,17,5,17,166,8,17,10,17,12,
        17,169,9,17,1,18,1,18,1,18,1,18,1,19,1,19,1,20,1,20,1,20,1,20,5,
        20,181,8,20,10,20,12,20,184,9,20,1,21,1,21,1,21,1,21,1,22,1,22,1,
        23,1,23,1,23,0,0,24,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,
        34,36,38,40,42,44,46,0,4,2,0,8,8,29,29,1,0,29,31,1,0,9,14,1,0,15,
        16,188,0,49,1,0,0,0,2,60,1,0,0,0,4,62,1,0,0,0,6,68,1,0,0,0,8,76,
        1,0,0,0,10,86,1,0,0,0,12,92,1,0,0,0,14,96,1,0,0,0,16,104,1,0,0,0,
        18,117,1,0,0,0,20,119,1,0,0,0,22,127,1,0,0,0,24,135,1,0,0,0,26,137,
        1,0,0,0,28,145,1,0,0,0,30,152,1,0,0,0,32,160,1,0,0,0,34,162,1,0,
        0,0,36,170,1,0,0,0,38,174,1,0,0,0,40,176,1,0,0,0,42,185,1,0,0,0,
        44,189,1,0,0,0,46,191,1,0,0,0,48,50,3,2,1,0,49,48,1,0,0,0,50,51,
        1,0,0,0,51,49,1,0,0,0,51,52,1,0,0,0,52,53,1,0,0,0,53,54,5,0,0,1,
        54,1,1,0,0,0,55,61,3,4,2,0,56,61,3,22,11,0,57,61,3,26,13,0,58,61,
        3,28,14,0,59,61,3,14,7,0,60,55,1,0,0,0,60,56,1,0,0,0,60,57,1,0,0,
        0,60,58,1,0,0,0,60,59,1,0,0,0,61,3,1,0,0,0,62,63,5,19,0,0,63,64,
        5,29,0,0,64,65,5,27,0,0,65,66,3,6,3,0,66,67,5,28,0,0,67,5,1,0,0,
        0,68,73,3,8,4,0,69,70,5,26,0,0,70,72,3,8,4,0,71,69,1,0,0,0,72,75,
        1,0,0,0,73,71,1,0,0,0,73,74,1,0,0,0,74,7,1,0,0,0,75,73,1,0,0,0,76,
        77,5,29,0,0,77,79,3,10,5,0,78,80,3,12,6,0,79,78,1,0,0,0,79,80,1,
        0,0,0,80,9,1,0,0,0,81,87,5,1,0,0,82,83,5,2,0,0,83,84,5,27,0,0,84,
        85,5,30,0,0,85,87,5,28,0,0,86,81,1,0,0,0,86,82,1,0,0,0,87,11,1,0,
        0,0,88,89,5,3,0,0,89,93,5,4,0,0,90,91,5,5,0,0,91,93,5,6,0,0,92,88,
        1,0,0,0,92,90,1,0,0,0,93,94,1,0,0,0,94,92,1,0,0,0,94,95,1,0,0,0,
        95,13,1,0,0,0,96,97,5,22,0,0,97,98,5,23,0,0,98,99,5,29,0,0,99,100,
        5,27,0,0,100,101,3,16,8,0,101,102,5,28,0,0,102,103,3,18,9,0,103,
        15,1,0,0,0,104,109,5,29,0,0,105,106,5,26,0,0,106,108,5,29,0,0,107,
        105,1,0,0,0,108,111,1,0,0,0,109,107,1,0,0,0,109,110,1,0,0,0,110,
        17,1,0,0,0,111,109,1,0,0,0,112,118,5,7,0,0,113,114,5,27,0,0,114,
        115,3,20,10,0,115,116,5,28,0,0,116,118,1,0,0,0,117,112,1,0,0,0,117,
        113,1,0,0,0,118,19,1,0,0,0,119,124,3,38,19,0,120,121,5,26,0,0,121,
        123,3,38,19,0,122,120,1,0,0,0,123,126,1,0,0,0,124,122,1,0,0,0,124,
        125,1,0,0,0,125,21,1,0,0,0,126,124,1,0,0,0,127,128,5,17,0,0,128,
        129,3,30,15,0,129,130,5,18,0,0,130,133,3,24,12,0,131,132,5,24,0,
        0,132,134,3,40,20,0,133,131,1,0,0,0,133,134,1,0,0,0,134,23,1,0,0,
        0,135,136,5,29,0,0,136,25,1,0,0,0,137,138,5,20,0,0,138,139,5,29,
        0,0,139,140,5,25,0,0,140,143,3,34,17,0,141,142,5,24,0,0,142,144,
        3,40,20,0,143,141,1,0,0,0,143,144,1,0,0,0,144,27,1,0,0,0,145,146,
        5,21,0,0,146,147,5,18,0,0,147,150,5,29,0,0,148,149,5,24,0,0,149,
        151,3,40,20,0,150,148,1,0,0,0,150,151,1,0,0,0,151,29,1,0,0,0,152,
        157,3,32,16,0,153,154,5,26,0,0,154,156,3,32,16,0,155,153,1,0,0,0,
        156,159,1,0,0,0,157,155,1,0,0,0,157,158,1,0,0,0,158,31,1,0,0,0,159,
        157,1,0,0,0,160,161,7,0,0,0,161,33,1,0,0,0,162,167,3,36,18,0,163,
        164,5,26,0,0,164,166,3,36,18,0,165,163,1,0,0,0,166,169,1,0,0,0,167,
        165,1,0,0,0,167,168,1,0,0,0,168,35,1,0,0,0,169,167,1,0,0,0,170,171,
        5,29,0,0,171,172,5,9,0,0,172,173,3,38,19,0,173,37,1,0,0,0,174,175,
        7,1,0,0,175,39,1,0,0,0,176,182,3,42,21,0,177,178,3,46,23,0,178,179,
        3,42,21,0,179,181,1,0,0,0,180,177,1,0,0,0,181,184,1,0,0,0,182,180,
        1,0,0,0,182,183,1,0,0,0,183,41,1,0,0,0,184,182,1,0,0,0,185,186,5,
        29,0,0,186,187,3,44,22,0,187,188,3,38,19,0,188,43,1,0,0,0,189,190,
        7,2,0,0,190,45,1,0,0,0,191,192,7,3,0,0,192,47,1,0,0,0,16,51,60,73,
        79,86,92,94,109,117,124,133,143,150,157,167,182
    ]

class CRUDParser ( Parser ):

    grammarFileName = "CRUD.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'NUMBER'", "'VARCHAR2'", "'PRIMARY'", 
                     "'KEY'", "'NOT'", "'NULL'", "'ejemplo'", "'*'", "'='", 
                     "'!='", "'<'", "'>'", "'<='", "'>='", "'and'", "'or'", 
                     "'^s'", "'^d'", "'+'", "'^u'", "'-'", "'metale'", "'en'", 
                     "'where'", "'set'", "','", "'('", "')'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "SELECT", "FROM", "CREATE", "UPDATE", 
                      "DELETE", "INSERT", "INTO", "WHERE", "SET", "COMA", 
                      "PAREN_IZQ", "PAREN_DER", "IDENTIFICADOR", "NUMERO", 
                      "CADENA", "WS" ]

    RULE_programa = 0
    RULE_comando = 1
    RULE_createCommand = 2
    RULE_definicionesColumnas = 3
    RULE_definicionColumna = 4
    RULE_tipoColumna = 5
    RULE_restricciones = 6
    RULE_insertCommand = 7
    RULE_columnasInsert = 8
    RULE_valoresInsert = 9
    RULE_valores = 10
    RULE_selectCommand = 11
    RULE_fromSource = 12
    RULE_updateCommand = 13
    RULE_deleteCommand = 14
    RULE_campos = 15
    RULE_campo = 16
    RULE_asignaciones = 17
    RULE_asignacion = 18
    RULE_valor = 19
    RULE_condicion = 20
    RULE_expresion = 21
    RULE_operador = 22
    RULE_operador_logico = 23

    ruleNames =  [ "programa", "comando", "createCommand", "definicionesColumnas", 
                   "definicionColumna", "tipoColumna", "restricciones", 
                   "insertCommand", "columnasInsert", "valoresInsert", "valores", 
                   "selectCommand", "fromSource", "updateCommand", "deleteCommand", 
                   "campos", "campo", "asignaciones", "asignacion", "valor", 
                   "condicion", "expresion", "operador", "operador_logico" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    SELECT=17
    FROM=18
    CREATE=19
    UPDATE=20
    DELETE=21
    INSERT=22
    INTO=23
    WHERE=24
    SET=25
    COMA=26
    PAREN_IZQ=27
    PAREN_DER=28
    IDENTIFICADOR=29
    NUMERO=30
    CADENA=31
    WS=32

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(CRUDParser.EOF, 0)

        def comando(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CRUDParser.ComandoContext)
            else:
                return self.getTypedRuleContext(CRUDParser.ComandoContext,i)


        def getRuleIndex(self):
            return CRUDParser.RULE_programa

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrograma" ):
                listener.enterPrograma(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrograma" ):
                listener.exitPrograma(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrograma" ):
                return visitor.visitPrograma(self)
            else:
                return visitor.visitChildren(self)




    def programa(self):

        localctx = CRUDParser.ProgramaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_programa)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 49 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 48
                self.comando()
                self.state = 51 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 7995392) != 0)):
                    break

            self.state = 53
            self.match(CRUDParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComandoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def createCommand(self):
            return self.getTypedRuleContext(CRUDParser.CreateCommandContext,0)


        def selectCommand(self):
            return self.getTypedRuleContext(CRUDParser.SelectCommandContext,0)


        def updateCommand(self):
            return self.getTypedRuleContext(CRUDParser.UpdateCommandContext,0)


        def deleteCommand(self):
            return self.getTypedRuleContext(CRUDParser.DeleteCommandContext,0)


        def insertCommand(self):
            return self.getTypedRuleContext(CRUDParser.InsertCommandContext,0)


        def getRuleIndex(self):
            return CRUDParser.RULE_comando

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComando" ):
                listener.enterComando(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComando" ):
                listener.exitComando(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComando" ):
                return visitor.visitComando(self)
            else:
                return visitor.visitChildren(self)




    def comando(self):

        localctx = CRUDParser.ComandoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_comando)
        try:
            self.state = 60
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [19]:
                self.enterOuterAlt(localctx, 1)
                self.state = 55
                self.createCommand()
                pass
            elif token in [17]:
                self.enterOuterAlt(localctx, 2)
                self.state = 56
                self.selectCommand()
                pass
            elif token in [20]:
                self.enterOuterAlt(localctx, 3)
                self.state = 57
                self.updateCommand()
                pass
            elif token in [21]:
                self.enterOuterAlt(localctx, 4)
                self.state = 58
                self.deleteCommand()
                pass
            elif token in [22]:
                self.enterOuterAlt(localctx, 5)
                self.state = 59
                self.insertCommand()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CreateCommandContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CREATE(self):
            return self.getToken(CRUDParser.CREATE, 0)

        def IDENTIFICADOR(self):
            return self.getToken(CRUDParser.IDENTIFICADOR, 0)

        def PAREN_IZQ(self):
            return self.getToken(CRUDParser.PAREN_IZQ, 0)

        def definicionesColumnas(self):
            return self.getTypedRuleContext(CRUDParser.DefinicionesColumnasContext,0)


        def PAREN_DER(self):
            return self.getToken(CRUDParser.PAREN_DER, 0)

        def getRuleIndex(self):
            return CRUDParser.RULE_createCommand

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCreateCommand" ):
                listener.enterCreateCommand(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCreateCommand" ):
                listener.exitCreateCommand(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCreateCommand" ):
                return visitor.visitCreateCommand(self)
            else:
                return visitor.visitChildren(self)




    def createCommand(self):

        localctx = CRUDParser.CreateCommandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_createCommand)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 62
            self.match(CRUDParser.CREATE)
            self.state = 63
            self.match(CRUDParser.IDENTIFICADOR)
            self.state = 64
            self.match(CRUDParser.PAREN_IZQ)
            self.state = 65
            self.definicionesColumnas()
            self.state = 66
            self.match(CRUDParser.PAREN_DER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DefinicionesColumnasContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def definicionColumna(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CRUDParser.DefinicionColumnaContext)
            else:
                return self.getTypedRuleContext(CRUDParser.DefinicionColumnaContext,i)


        def COMA(self, i:int=None):
            if i is None:
                return self.getTokens(CRUDParser.COMA)
            else:
                return self.getToken(CRUDParser.COMA, i)

        def getRuleIndex(self):
            return CRUDParser.RULE_definicionesColumnas

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefinicionesColumnas" ):
                listener.enterDefinicionesColumnas(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefinicionesColumnas" ):
                listener.exitDefinicionesColumnas(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDefinicionesColumnas" ):
                return visitor.visitDefinicionesColumnas(self)
            else:
                return visitor.visitChildren(self)




    def definicionesColumnas(self):

        localctx = CRUDParser.DefinicionesColumnasContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_definicionesColumnas)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 68
            self.definicionColumna()
            self.state = 73
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==26:
                self.state = 69
                self.match(CRUDParser.COMA)
                self.state = 70
                self.definicionColumna()
                self.state = 75
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DefinicionColumnaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(CRUDParser.IDENTIFICADOR, 0)

        def tipoColumna(self):
            return self.getTypedRuleContext(CRUDParser.TipoColumnaContext,0)


        def restricciones(self):
            return self.getTypedRuleContext(CRUDParser.RestriccionesContext,0)


        def getRuleIndex(self):
            return CRUDParser.RULE_definicionColumna

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefinicionColumna" ):
                listener.enterDefinicionColumna(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefinicionColumna" ):
                listener.exitDefinicionColumna(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDefinicionColumna" ):
                return visitor.visitDefinicionColumna(self)
            else:
                return visitor.visitChildren(self)




    def definicionColumna(self):

        localctx = CRUDParser.DefinicionColumnaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_definicionColumna)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 76
            self.match(CRUDParser.IDENTIFICADOR)
            self.state = 77
            self.tipoColumna()
            self.state = 79
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==3 or _la==5:
                self.state = 78
                self.restricciones()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TipoColumnaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PAREN_IZQ(self):
            return self.getToken(CRUDParser.PAREN_IZQ, 0)

        def NUMERO(self):
            return self.getToken(CRUDParser.NUMERO, 0)

        def PAREN_DER(self):
            return self.getToken(CRUDParser.PAREN_DER, 0)

        def getRuleIndex(self):
            return CRUDParser.RULE_tipoColumna

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTipoColumna" ):
                listener.enterTipoColumna(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTipoColumna" ):
                listener.exitTipoColumna(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTipoColumna" ):
                return visitor.visitTipoColumna(self)
            else:
                return visitor.visitChildren(self)




    def tipoColumna(self):

        localctx = CRUDParser.TipoColumnaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_tipoColumna)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 86
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1]:
                self.state = 81
                self.match(CRUDParser.T__0)
                pass
            elif token in [2]:
                self.state = 82
                self.match(CRUDParser.T__1)
                self.state = 83
                self.match(CRUDParser.PAREN_IZQ)
                self.state = 84
                self.match(CRUDParser.NUMERO)
                self.state = 85
                self.match(CRUDParser.PAREN_DER)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RestriccionesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CRUDParser.RULE_restricciones

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRestricciones" ):
                listener.enterRestricciones(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRestricciones" ):
                listener.exitRestricciones(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRestricciones" ):
                return visitor.visitRestricciones(self)
            else:
                return visitor.visitChildren(self)




    def restricciones(self):

        localctx = CRUDParser.RestriccionesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_restricciones)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 92 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 92
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [3]:
                    self.state = 88
                    self.match(CRUDParser.T__2)
                    self.state = 89
                    self.match(CRUDParser.T__3)
                    pass
                elif token in [5]:
                    self.state = 90
                    self.match(CRUDParser.T__4)
                    self.state = 91
                    self.match(CRUDParser.T__5)
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 94 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==3 or _la==5):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InsertCommandContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INSERT(self):
            return self.getToken(CRUDParser.INSERT, 0)

        def INTO(self):
            return self.getToken(CRUDParser.INTO, 0)

        def IDENTIFICADOR(self):
            return self.getToken(CRUDParser.IDENTIFICADOR, 0)

        def PAREN_IZQ(self):
            return self.getToken(CRUDParser.PAREN_IZQ, 0)

        def columnasInsert(self):
            return self.getTypedRuleContext(CRUDParser.ColumnasInsertContext,0)


        def PAREN_DER(self):
            return self.getToken(CRUDParser.PAREN_DER, 0)

        def valoresInsert(self):
            return self.getTypedRuleContext(CRUDParser.ValoresInsertContext,0)


        def getRuleIndex(self):
            return CRUDParser.RULE_insertCommand

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInsertCommand" ):
                listener.enterInsertCommand(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInsertCommand" ):
                listener.exitInsertCommand(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInsertCommand" ):
                return visitor.visitInsertCommand(self)
            else:
                return visitor.visitChildren(self)




    def insertCommand(self):

        localctx = CRUDParser.InsertCommandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_insertCommand)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 96
            self.match(CRUDParser.INSERT)
            self.state = 97
            self.match(CRUDParser.INTO)
            self.state = 98
            self.match(CRUDParser.IDENTIFICADOR)
            self.state = 99
            self.match(CRUDParser.PAREN_IZQ)
            self.state = 100
            self.columnasInsert()
            self.state = 101
            self.match(CRUDParser.PAREN_DER)
            self.state = 102
            self.valoresInsert()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ColumnasInsertContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self, i:int=None):
            if i is None:
                return self.getTokens(CRUDParser.IDENTIFICADOR)
            else:
                return self.getToken(CRUDParser.IDENTIFICADOR, i)

        def COMA(self, i:int=None):
            if i is None:
                return self.getTokens(CRUDParser.COMA)
            else:
                return self.getToken(CRUDParser.COMA, i)

        def getRuleIndex(self):
            return CRUDParser.RULE_columnasInsert

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterColumnasInsert" ):
                listener.enterColumnasInsert(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitColumnasInsert" ):
                listener.exitColumnasInsert(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitColumnasInsert" ):
                return visitor.visitColumnasInsert(self)
            else:
                return visitor.visitChildren(self)




    def columnasInsert(self):

        localctx = CRUDParser.ColumnasInsertContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_columnasInsert)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 104
            self.match(CRUDParser.IDENTIFICADOR)
            self.state = 109
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==26:
                self.state = 105
                self.match(CRUDParser.COMA)
                self.state = 106
                self.match(CRUDParser.IDENTIFICADOR)
                self.state = 111
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValoresInsertContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PAREN_IZQ(self):
            return self.getToken(CRUDParser.PAREN_IZQ, 0)

        def valores(self):
            return self.getTypedRuleContext(CRUDParser.ValoresContext,0)


        def PAREN_DER(self):
            return self.getToken(CRUDParser.PAREN_DER, 0)

        def getRuleIndex(self):
            return CRUDParser.RULE_valoresInsert

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValoresInsert" ):
                listener.enterValoresInsert(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValoresInsert" ):
                listener.exitValoresInsert(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitValoresInsert" ):
                return visitor.visitValoresInsert(self)
            else:
                return visitor.visitChildren(self)




    def valoresInsert(self):

        localctx = CRUDParser.ValoresInsertContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_valoresInsert)
        try:
            self.state = 117
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [7]:
                self.enterOuterAlt(localctx, 1)
                self.state = 112
                self.match(CRUDParser.T__6)
                pass
            elif token in [27]:
                self.enterOuterAlt(localctx, 2)
                self.state = 113
                self.match(CRUDParser.PAREN_IZQ)
                self.state = 114
                self.valores()
                self.state = 115
                self.match(CRUDParser.PAREN_DER)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValoresContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def valor(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CRUDParser.ValorContext)
            else:
                return self.getTypedRuleContext(CRUDParser.ValorContext,i)


        def COMA(self, i:int=None):
            if i is None:
                return self.getTokens(CRUDParser.COMA)
            else:
                return self.getToken(CRUDParser.COMA, i)

        def getRuleIndex(self):
            return CRUDParser.RULE_valores

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValores" ):
                listener.enterValores(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValores" ):
                listener.exitValores(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitValores" ):
                return visitor.visitValores(self)
            else:
                return visitor.visitChildren(self)




    def valores(self):

        localctx = CRUDParser.ValoresContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_valores)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 119
            self.valor()
            self.state = 124
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==26:
                self.state = 120
                self.match(CRUDParser.COMA)
                self.state = 121
                self.valor()
                self.state = 126
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SelectCommandContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SELECT(self):
            return self.getToken(CRUDParser.SELECT, 0)

        def campos(self):
            return self.getTypedRuleContext(CRUDParser.CamposContext,0)


        def FROM(self):
            return self.getToken(CRUDParser.FROM, 0)

        def fromSource(self):
            return self.getTypedRuleContext(CRUDParser.FromSourceContext,0)


        def WHERE(self):
            return self.getToken(CRUDParser.WHERE, 0)

        def condicion(self):
            return self.getTypedRuleContext(CRUDParser.CondicionContext,0)


        def getRuleIndex(self):
            return CRUDParser.RULE_selectCommand

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSelectCommand" ):
                listener.enterSelectCommand(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSelectCommand" ):
                listener.exitSelectCommand(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSelectCommand" ):
                return visitor.visitSelectCommand(self)
            else:
                return visitor.visitChildren(self)




    def selectCommand(self):

        localctx = CRUDParser.SelectCommandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_selectCommand)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 127
            self.match(CRUDParser.SELECT)
            self.state = 128
            self.campos()
            self.state = 129
            self.match(CRUDParser.FROM)
            self.state = 130
            self.fromSource()
            self.state = 133
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 131
                self.match(CRUDParser.WHERE)
                self.state = 132
                self.condicion()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FromSourceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(CRUDParser.IDENTIFICADOR, 0)

        def getRuleIndex(self):
            return CRUDParser.RULE_fromSource

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFromSource" ):
                listener.enterFromSource(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFromSource" ):
                listener.exitFromSource(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFromSource" ):
                return visitor.visitFromSource(self)
            else:
                return visitor.visitChildren(self)




    def fromSource(self):

        localctx = CRUDParser.FromSourceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_fromSource)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 135
            self.match(CRUDParser.IDENTIFICADOR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UpdateCommandContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def UPDATE(self):
            return self.getToken(CRUDParser.UPDATE, 0)

        def IDENTIFICADOR(self):
            return self.getToken(CRUDParser.IDENTIFICADOR, 0)

        def SET(self):
            return self.getToken(CRUDParser.SET, 0)

        def asignaciones(self):
            return self.getTypedRuleContext(CRUDParser.AsignacionesContext,0)


        def WHERE(self):
            return self.getToken(CRUDParser.WHERE, 0)

        def condicion(self):
            return self.getTypedRuleContext(CRUDParser.CondicionContext,0)


        def getRuleIndex(self):
            return CRUDParser.RULE_updateCommand

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUpdateCommand" ):
                listener.enterUpdateCommand(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUpdateCommand" ):
                listener.exitUpdateCommand(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUpdateCommand" ):
                return visitor.visitUpdateCommand(self)
            else:
                return visitor.visitChildren(self)




    def updateCommand(self):

        localctx = CRUDParser.UpdateCommandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_updateCommand)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 137
            self.match(CRUDParser.UPDATE)
            self.state = 138
            self.match(CRUDParser.IDENTIFICADOR)
            self.state = 139
            self.match(CRUDParser.SET)
            self.state = 140
            self.asignaciones()
            self.state = 143
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 141
                self.match(CRUDParser.WHERE)
                self.state = 142
                self.condicion()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeleteCommandContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DELETE(self):
            return self.getToken(CRUDParser.DELETE, 0)

        def FROM(self):
            return self.getToken(CRUDParser.FROM, 0)

        def IDENTIFICADOR(self):
            return self.getToken(CRUDParser.IDENTIFICADOR, 0)

        def WHERE(self):
            return self.getToken(CRUDParser.WHERE, 0)

        def condicion(self):
            return self.getTypedRuleContext(CRUDParser.CondicionContext,0)


        def getRuleIndex(self):
            return CRUDParser.RULE_deleteCommand

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeleteCommand" ):
                listener.enterDeleteCommand(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeleteCommand" ):
                listener.exitDeleteCommand(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeleteCommand" ):
                return visitor.visitDeleteCommand(self)
            else:
                return visitor.visitChildren(self)




    def deleteCommand(self):

        localctx = CRUDParser.DeleteCommandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_deleteCommand)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 145
            self.match(CRUDParser.DELETE)
            self.state = 146
            self.match(CRUDParser.FROM)
            self.state = 147
            self.match(CRUDParser.IDENTIFICADOR)
            self.state = 150
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 148
                self.match(CRUDParser.WHERE)
                self.state = 149
                self.condicion()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CamposContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def campo(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CRUDParser.CampoContext)
            else:
                return self.getTypedRuleContext(CRUDParser.CampoContext,i)


        def COMA(self, i:int=None):
            if i is None:
                return self.getTokens(CRUDParser.COMA)
            else:
                return self.getToken(CRUDParser.COMA, i)

        def getRuleIndex(self):
            return CRUDParser.RULE_campos

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCampos" ):
                listener.enterCampos(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCampos" ):
                listener.exitCampos(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCampos" ):
                return visitor.visitCampos(self)
            else:
                return visitor.visitChildren(self)




    def campos(self):

        localctx = CRUDParser.CamposContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_campos)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 152
            self.campo()
            self.state = 157
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==26:
                self.state = 153
                self.match(CRUDParser.COMA)
                self.state = 154
                self.campo()
                self.state = 159
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CampoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(CRUDParser.IDENTIFICADOR, 0)

        def getRuleIndex(self):
            return CRUDParser.RULE_campo

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCampo" ):
                listener.enterCampo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCampo" ):
                listener.exitCampo(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCampo" ):
                return visitor.visitCampo(self)
            else:
                return visitor.visitChildren(self)




    def campo(self):

        localctx = CRUDParser.CampoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_campo)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 160
            _la = self._input.LA(1)
            if not(_la==8 or _la==29):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AsignacionesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def asignacion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CRUDParser.AsignacionContext)
            else:
                return self.getTypedRuleContext(CRUDParser.AsignacionContext,i)


        def COMA(self, i:int=None):
            if i is None:
                return self.getTokens(CRUDParser.COMA)
            else:
                return self.getToken(CRUDParser.COMA, i)

        def getRuleIndex(self):
            return CRUDParser.RULE_asignaciones

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAsignaciones" ):
                listener.enterAsignaciones(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAsignaciones" ):
                listener.exitAsignaciones(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAsignaciones" ):
                return visitor.visitAsignaciones(self)
            else:
                return visitor.visitChildren(self)




    def asignaciones(self):

        localctx = CRUDParser.AsignacionesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_asignaciones)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 162
            self.asignacion()
            self.state = 167
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==26:
                self.state = 163
                self.match(CRUDParser.COMA)
                self.state = 164
                self.asignacion()
                self.state = 169
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AsignacionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(CRUDParser.IDENTIFICADOR, 0)

        def valor(self):
            return self.getTypedRuleContext(CRUDParser.ValorContext,0)


        def getRuleIndex(self):
            return CRUDParser.RULE_asignacion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAsignacion" ):
                listener.enterAsignacion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAsignacion" ):
                listener.exitAsignacion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAsignacion" ):
                return visitor.visitAsignacion(self)
            else:
                return visitor.visitChildren(self)




    def asignacion(self):

        localctx = CRUDParser.AsignacionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_asignacion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 170
            self.match(CRUDParser.IDENTIFICADOR)
            self.state = 171
            self.match(CRUDParser.T__8)
            self.state = 172
            self.valor()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CADENA(self):
            return self.getToken(CRUDParser.CADENA, 0)

        def NUMERO(self):
            return self.getToken(CRUDParser.NUMERO, 0)

        def IDENTIFICADOR(self):
            return self.getToken(CRUDParser.IDENTIFICADOR, 0)

        def getRuleIndex(self):
            return CRUDParser.RULE_valor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValor" ):
                listener.enterValor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValor" ):
                listener.exitValor(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitValor" ):
                return visitor.visitValor(self)
            else:
                return visitor.visitChildren(self)




    def valor(self):

        localctx = CRUDParser.ValorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_valor)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 174
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 3758096384) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CondicionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expresion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CRUDParser.ExpresionContext)
            else:
                return self.getTypedRuleContext(CRUDParser.ExpresionContext,i)


        def operador_logico(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(CRUDParser.Operador_logicoContext)
            else:
                return self.getTypedRuleContext(CRUDParser.Operador_logicoContext,i)


        def getRuleIndex(self):
            return CRUDParser.RULE_condicion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondicion" ):
                listener.enterCondicion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondicion" ):
                listener.exitCondicion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCondicion" ):
                return visitor.visitCondicion(self)
            else:
                return visitor.visitChildren(self)




    def condicion(self):

        localctx = CRUDParser.CondicionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_condicion)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 176
            self.expresion()
            self.state = 182
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==15 or _la==16:
                self.state = 177
                self.operador_logico()
                self.state = 178
                self.expresion()
                self.state = 184
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpresionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFICADOR(self):
            return self.getToken(CRUDParser.IDENTIFICADOR, 0)

        def operador(self):
            return self.getTypedRuleContext(CRUDParser.OperadorContext,0)


        def valor(self):
            return self.getTypedRuleContext(CRUDParser.ValorContext,0)


        def getRuleIndex(self):
            return CRUDParser.RULE_expresion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpresion" ):
                listener.enterExpresion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpresion" ):
                listener.exitExpresion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpresion" ):
                return visitor.visitExpresion(self)
            else:
                return visitor.visitChildren(self)




    def expresion(self):

        localctx = CRUDParser.ExpresionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_expresion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 185
            self.match(CRUDParser.IDENTIFICADOR)
            self.state = 186
            self.operador()
            self.state = 187
            self.valor()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OperadorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CRUDParser.RULE_operador

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOperador" ):
                listener.enterOperador(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOperador" ):
                listener.exitOperador(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOperador" ):
                return visitor.visitOperador(self)
            else:
                return visitor.visitChildren(self)




    def operador(self):

        localctx = CRUDParser.OperadorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_operador)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 189
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 32256) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Operador_logicoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return CRUDParser.RULE_operador_logico

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOperador_logico" ):
                listener.enterOperador_logico(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOperador_logico" ):
                listener.exitOperador_logico(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOperador_logico" ):
                return visitor.visitOperador_logico(self)
            else:
                return visitor.visitChildren(self)




    def operador_logico(self):

        localctx = CRUDParser.Operador_logicoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_operador_logico)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 191
            _la = self._input.LA(1)
            if not(_la==15 or _la==16):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





