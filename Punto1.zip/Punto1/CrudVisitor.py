import sys
import os
from antlr4 import *
from CRUDLexer import CRUDLexer
from CRUDParser import CRUDParser

try:
    from CRUDVisitor import CRUDVisitor
except ImportError:
    class CRUDVisitor:
        def visit(self, ctx):
            return self.visitChildren(ctx)
        
        def visitChildren(self, ctx):
            result = None
            for child in ctx.getChildren():
                if hasattr(child, 'accept'):
                    result = child.accept(self)
            return result
        
        def visitTerminal(self, node):
            return node.getText()
        
        def visitErrorNode(self, node):
            return node.getText()

class MyCRUDVisitor(CRUDVisitor):
    def __init__(self):
        super().__init__()
        self.database = {}          # Almacenar tablas 
        self.table_schemas = {}     # Almacenar esquemas
    
    # Función principal: inicia la ejecución del CRUD
    def visitPrograma(self, ctx):
        print("___ Pruebas ___")
        result = self.visitChildren(ctx)
        return result
    
    # CREATE:que es + 
    def visitCreateCommand(self, ctx):
        table = ctx.IDENTIFICADOR().getText()
        definiciones = self.visit(ctx.definicionesColumnas())
        self.database[table] = []  # Lista vacía para registros
        self.table_schemas[table] = definiciones  # Guardar columnas
        
        print(f"CREANDO TABLA: {table}")
        print(f"  Columnas: {definiciones}")
        return None
    
    # Función recorre y devuelve columnas
    def visitDefinicionesColumnas(self, ctx):
        columnas = []
        for columna in ctx.definicionColumna():
            columnas.append(self.visit(columna))
        return columnas
    
    def visitDefinicionColumna(self, ctx):
        nombre = ctx.IDENTIFICADOR().getText()
        tipo = self.visit(ctx.tipoColumna())
        restricciones = self.visit(ctx.restricciones()) if ctx.restricciones() else ""
        return {"nombre": nombre, "tipo": tipo, "restricciones": restricciones}
    
    def visitTipoColumna(self, ctx):
        if ctx.getText().startswith('NUMBER'):
            return "NUMBER"
        else:
            size = ctx.NUMERO().getText()
            return f"VARCHAR2({size})"
    
    # Función restricciones
    def visitRestricciones(self, ctx):
        restricciones = []
        for i in range(0, len(ctx.children), 2):
            if i + 1 < len(ctx.children):
                restricciones.append(f"{ctx.children[i].getText()} {ctx.children[i+1].getText()}")
        return " ".join(restricciones)
    
    # Función INSERT: metale
    def visitInsertCommand(self, ctx):
        tabla = ctx.IDENTIFICADOR().getText()
        columnas = self.visit(ctx.columnasInsert())
        
        if ctx.valoresInsert().getText() == 'ejemplo':
            registro_ejemplo = {"id": 1, "nombre": "Ejemplo"}
            self.database[tabla].append(registro_ejemplo)
            print(f"INSERTANDO en: {tabla}")
            print(f"  Datos: {registro_ejemplo}")
        else:
            valores = self.visit(ctx.valoresInsert())
            registro = {}
            for i, columna in enumerate(columnas):
                if i < len(valores):
                    registro[columna] = valores[i]
            self.database[tabla].append(registro)
            print(f"INSERTANDO en: {tabla}")
            print(f"  Datos: {registro}")
        return None
    
    def visitColumnasInsert(self, ctx):
        return [id.getText() for id in ctx.IDENTIFICADOR()]
    
    # Función valores del metale
    def visitValoresInsert(self, ctx):
        if ctx.getText() == 'ejemplo':
            return "EJEMPLO"
        else:
            return self.visit(ctx.valores())
    
    def visitValores(self, ctx):
        valores = []
        for valor_ctx in ctx.valor():
            valor_text = valor_ctx.getText()
            if valor_text.startswith("'") and valor_text.endswith("'"):
                valor_text = valor_text[1:-1]
            valores.append(valor_text)
        return valores
    
    # Función SELECT: ^s 
    def visitSelectCommand(self, ctx):
        try:
            campos = self.visit(ctx.campos())
            tabla = ctx.fromSource().IDENTIFICADOR().getText()
            
            print(f"CONSULTANDO: SELECT {campos} FROM {tabla}")
            
            if tabla in self.database:
                print(f"  RESULTADOS:")
                for registro in self.database[tabla]:
                    print(f"    {registro}")
            else:
                print(f"  Tabla '{tabla}' no encontrada")
                
        except Exception as e:
            print(f"Error en SELECT: {e}")
            import traceback
            traceback.print_exc()
        return None
    
    # Función UPDATE: muestra una actualización de registros
    def visitUpdateCommand(self, ctx):
        try:
            tabla = ctx.IDENTIFICADOR().getText()
            asignaciones = self.visit(ctx.asignaciones())
            condicion_text = self.visit(ctx.condicion()) if ctx.condicion() else "Sin condición"
            print(f"ACTUALIZANDO: UPDATE {tabla} SET {asignaciones} WHERE {condicion_text}")
        except Exception as e:
            print(f"Error en UPDATE: {e}")
        return None
    
    # Función DELETE: - 
    def visitDeleteCommand(self, ctx):
        try:
            tabla = ctx.IDENTIFICADOR().getText()
            condicion_text = self.visit(ctx.condicion()) if ctx.condicion() else "Sin condición"
            print(f"ELIMINANDO: DELETE FROM {tabla} WHERE {condicion_text}")
        except Exception as e:
            print(f"Error en DELETE: {e}")
        return None
    
    def visitCampos(self, ctx):
        campos = []
        for campo_ctx in ctx.campo():
            campos.append(self.visit(campo_ctx))
        return ", ".join(campos)
    
    # Función que interpreta un campo individual
    def visitCampo(self, ctx):
        if ctx.IDENTIFICADOR():
            return ctx.IDENTIFICADOR().getText()
        elif ctx.getText() == '*':
            return "*"
        return ctx.getText()
    
    # Función que agrupa todas las asignaciones del UPDATE
    def visitAsignaciones(self, ctx):
        asignaciones = []
        for asignacion in ctx.asignacion():
            asignaciones.append(self.visit(asignacion))
        return ", ".join(asignaciones)
    
    # Función que forma una asignación campo = valor
    def visitAsignacion(self, ctx):
        campo = ctx.IDENTIFICADOR().getText()
        valor_text = ctx.valor().getText()
        return f"{campo} = {valor_text}"
    
    # Función que maneja condiciones WHERE
    def visitCondicion(self, ctx):
        expresiones = []
        for expr in ctx.expresion():
            expresiones.append(self.visit(expr))
        if len(expresiones) > 1:
            return " AND ".join(expresiones)
        return expresiones[0] if expresiones else "Sin condición"
    
    # Función interpreta WHERE
    def visitExpresion(self, ctx):
        campo = ctx.IDENTIFICADOR().getText()
        operador = ctx.operador().getText()
        valor = ctx.valor().getText()
        return f"{campo} {operador} {valor}"
    
    # Métodos requeridos por la interfaz de Visitor
    def visitTerminal(self, node):
        return node.getText()
    
    def visitErrorNode(self, node):
        return node.getText()

def main():
    if len(sys.argv) != 2:
        print("Uso: python CrudVisitor.py archivo.txt")
        return
    
    input_file = sys.argv[1]
    if not os.path.exists(input_file):
        print(f"Error: El archivo {input_file} no existe")
        return
    
    try:
        input_stream = FileStream(input_file, encoding='utf-8')
        lexer = CRUDLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = CRUDParser(stream)
        tree = parser.programa()
        visitor = MyCRUDVisitor()
        visitor.visit(tree)
        
    except Exception as e:
        print(f"Error durante la ejecución: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()
