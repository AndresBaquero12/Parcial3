# Generated from CRUD.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .CRUDParser import CRUDParser
else:
    from CRUDParser import CRUDParser

# This class defines a complete generic visitor for a parse tree produced by CRUDParser.

class CRUDVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by CRUDParser#programa.
    def visitPrograma(self, ctx:CRUDParser.ProgramaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#comando.
    def visitComando(self, ctx:CRUDParser.ComandoContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#createCommand.
    def visitCreateCommand(self, ctx:CRUDParser.CreateCommandContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#definicionesColumnas.
    def visitDefinicionesColumnas(self, ctx:CRUDParser.DefinicionesColumnasContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#definicionColumna.
    def visitDefinicionColumna(self, ctx:CRUDParser.DefinicionColumnaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#tipoColumna.
    def visitTipoColumna(self, ctx:CRUDParser.TipoColumnaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#restricciones.
    def visitRestricciones(self, ctx:CRUDParser.RestriccionesContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#insertCommand.
    def visitInsertCommand(self, ctx:CRUDParser.InsertCommandContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#columnasInsert.
    def visitColumnasInsert(self, ctx:CRUDParser.ColumnasInsertContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#valoresInsert.
    def visitValoresInsert(self, ctx:CRUDParser.ValoresInsertContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#valores.
    def visitValores(self, ctx:CRUDParser.ValoresContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#selectCommand.
    def visitSelectCommand(self, ctx:CRUDParser.SelectCommandContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#fromSource.
    def visitFromSource(self, ctx:CRUDParser.FromSourceContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#updateCommand.
    def visitUpdateCommand(self, ctx:CRUDParser.UpdateCommandContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#deleteCommand.
    def visitDeleteCommand(self, ctx:CRUDParser.DeleteCommandContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#campos.
    def visitCampos(self, ctx:CRUDParser.CamposContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#campo.
    def visitCampo(self, ctx:CRUDParser.CampoContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#asignaciones.
    def visitAsignaciones(self, ctx:CRUDParser.AsignacionesContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#asignacion.
    def visitAsignacion(self, ctx:CRUDParser.AsignacionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#valor.
    def visitValor(self, ctx:CRUDParser.ValorContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#condicion.
    def visitCondicion(self, ctx:CRUDParser.CondicionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#expresion.
    def visitExpresion(self, ctx:CRUDParser.ExpresionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#operador.
    def visitOperador(self, ctx:CRUDParser.OperadorContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by CRUDParser#operador_logico.
    def visitOperador_logico(self, ctx:CRUDParser.Operador_logicoContext):
        return self.visitChildren(ctx)



del CRUDParser