# Generated from CRUD.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .CRUDParser import CRUDParser
else:
    from CRUDParser import CRUDParser

# This class defines a complete listener for a parse tree produced by CRUDParser.
class CRUDListener(ParseTreeListener):

    # Enter a parse tree produced by CRUDParser#programa.
    def enterPrograma(self, ctx:CRUDParser.ProgramaContext):
        pass

    # Exit a parse tree produced by CRUDParser#programa.
    def exitPrograma(self, ctx:CRUDParser.ProgramaContext):
        pass


    # Enter a parse tree produced by CRUDParser#comando.
    def enterComando(self, ctx:CRUDParser.ComandoContext):
        pass

    # Exit a parse tree produced by CRUDParser#comando.
    def exitComando(self, ctx:CRUDParser.ComandoContext):
        pass


    # Enter a parse tree produced by CRUDParser#createCommand.
    def enterCreateCommand(self, ctx:CRUDParser.CreateCommandContext):
        pass

    # Exit a parse tree produced by CRUDParser#createCommand.
    def exitCreateCommand(self, ctx:CRUDParser.CreateCommandContext):
        pass


    # Enter a parse tree produced by CRUDParser#definicionesColumnas.
    def enterDefinicionesColumnas(self, ctx:CRUDParser.DefinicionesColumnasContext):
        pass

    # Exit a parse tree produced by CRUDParser#definicionesColumnas.
    def exitDefinicionesColumnas(self, ctx:CRUDParser.DefinicionesColumnasContext):
        pass


    # Enter a parse tree produced by CRUDParser#definicionColumna.
    def enterDefinicionColumna(self, ctx:CRUDParser.DefinicionColumnaContext):
        pass

    # Exit a parse tree produced by CRUDParser#definicionColumna.
    def exitDefinicionColumna(self, ctx:CRUDParser.DefinicionColumnaContext):
        pass


    # Enter a parse tree produced by CRUDParser#tipoColumna.
    def enterTipoColumna(self, ctx:CRUDParser.TipoColumnaContext):
        pass

    # Exit a parse tree produced by CRUDParser#tipoColumna.
    def exitTipoColumna(self, ctx:CRUDParser.TipoColumnaContext):
        pass


    # Enter a parse tree produced by CRUDParser#restricciones.
    def enterRestricciones(self, ctx:CRUDParser.RestriccionesContext):
        pass

    # Exit a parse tree produced by CRUDParser#restricciones.
    def exitRestricciones(self, ctx:CRUDParser.RestriccionesContext):
        pass


    # Enter a parse tree produced by CRUDParser#insertCommand.
    def enterInsertCommand(self, ctx:CRUDParser.InsertCommandContext):
        pass

    # Exit a parse tree produced by CRUDParser#insertCommand.
    def exitInsertCommand(self, ctx:CRUDParser.InsertCommandContext):
        pass


    # Enter a parse tree produced by CRUDParser#columnasInsert.
    def enterColumnasInsert(self, ctx:CRUDParser.ColumnasInsertContext):
        pass

    # Exit a parse tree produced by CRUDParser#columnasInsert.
    def exitColumnasInsert(self, ctx:CRUDParser.ColumnasInsertContext):
        pass


    # Enter a parse tree produced by CRUDParser#valoresInsert.
    def enterValoresInsert(self, ctx:CRUDParser.ValoresInsertContext):
        pass

    # Exit a parse tree produced by CRUDParser#valoresInsert.
    def exitValoresInsert(self, ctx:CRUDParser.ValoresInsertContext):
        pass


    # Enter a parse tree produced by CRUDParser#valores.
    def enterValores(self, ctx:CRUDParser.ValoresContext):
        pass

    # Exit a parse tree produced by CRUDParser#valores.
    def exitValores(self, ctx:CRUDParser.ValoresContext):
        pass


    # Enter a parse tree produced by CRUDParser#selectCommand.
    def enterSelectCommand(self, ctx:CRUDParser.SelectCommandContext):
        pass

    # Exit a parse tree produced by CRUDParser#selectCommand.
    def exitSelectCommand(self, ctx:CRUDParser.SelectCommandContext):
        pass


    # Enter a parse tree produced by CRUDParser#fromSource.
    def enterFromSource(self, ctx:CRUDParser.FromSourceContext):
        pass

    # Exit a parse tree produced by CRUDParser#fromSource.
    def exitFromSource(self, ctx:CRUDParser.FromSourceContext):
        pass


    # Enter a parse tree produced by CRUDParser#updateCommand.
    def enterUpdateCommand(self, ctx:CRUDParser.UpdateCommandContext):
        pass

    # Exit a parse tree produced by CRUDParser#updateCommand.
    def exitUpdateCommand(self, ctx:CRUDParser.UpdateCommandContext):
        pass


    # Enter a parse tree produced by CRUDParser#deleteCommand.
    def enterDeleteCommand(self, ctx:CRUDParser.DeleteCommandContext):
        pass

    # Exit a parse tree produced by CRUDParser#deleteCommand.
    def exitDeleteCommand(self, ctx:CRUDParser.DeleteCommandContext):
        pass


    # Enter a parse tree produced by CRUDParser#campos.
    def enterCampos(self, ctx:CRUDParser.CamposContext):
        pass

    # Exit a parse tree produced by CRUDParser#campos.
    def exitCampos(self, ctx:CRUDParser.CamposContext):
        pass


    # Enter a parse tree produced by CRUDParser#campo.
    def enterCampo(self, ctx:CRUDParser.CampoContext):
        pass

    # Exit a parse tree produced by CRUDParser#campo.
    def exitCampo(self, ctx:CRUDParser.CampoContext):
        pass


    # Enter a parse tree produced by CRUDParser#asignaciones.
    def enterAsignaciones(self, ctx:CRUDParser.AsignacionesContext):
        pass

    # Exit a parse tree produced by CRUDParser#asignaciones.
    def exitAsignaciones(self, ctx:CRUDParser.AsignacionesContext):
        pass


    # Enter a parse tree produced by CRUDParser#asignacion.
    def enterAsignacion(self, ctx:CRUDParser.AsignacionContext):
        pass

    # Exit a parse tree produced by CRUDParser#asignacion.
    def exitAsignacion(self, ctx:CRUDParser.AsignacionContext):
        pass


    # Enter a parse tree produced by CRUDParser#valor.
    def enterValor(self, ctx:CRUDParser.ValorContext):
        pass

    # Exit a parse tree produced by CRUDParser#valor.
    def exitValor(self, ctx:CRUDParser.ValorContext):
        pass


    # Enter a parse tree produced by CRUDParser#condicion.
    def enterCondicion(self, ctx:CRUDParser.CondicionContext):
        pass

    # Exit a parse tree produced by CRUDParser#condicion.
    def exitCondicion(self, ctx:CRUDParser.CondicionContext):
        pass


    # Enter a parse tree produced by CRUDParser#expresion.
    def enterExpresion(self, ctx:CRUDParser.ExpresionContext):
        pass

    # Exit a parse tree produced by CRUDParser#expresion.
    def exitExpresion(self, ctx:CRUDParser.ExpresionContext):
        pass


    # Enter a parse tree produced by CRUDParser#operador.
    def enterOperador(self, ctx:CRUDParser.OperadorContext):
        pass

    # Exit a parse tree produced by CRUDParser#operador.
    def exitOperador(self, ctx:CRUDParser.OperadorContext):
        pass


    # Enter a parse tree produced by CRUDParser#operador_logico.
    def enterOperador_logico(self, ctx:CRUDParser.Operador_logicoContext):
        pass

    # Exit a parse tree produced by CRUDParser#operador_logico.
    def exitOperador_logico(self, ctx:CRUDParser.Operador_logicoContext):
        pass



del CRUDParser